# GitHub公开发布与同步 0.5.0

公开地址为 https://jiayilong246.github.io/zhixi/ 。使用 JiayiLong246 的现有主页仓库，在 zhixi 目录提供在线刷题、阅读版和完整工具包下载。

本次初始公开题库取自你提供的 zhixi-questions-2026-11-11.html，共802题，全部具备可解析的答案。原阅读版保持本次上传内容。随包本地刷题网站也带有这802题，原801题PDF及分类手册仍是旧整理资料。

## 启用自动同步

1. 更新原扩展目录，重新加载扩展并刷新学校练习页面。
2. 用 JiayiLong246 登录 GitHub，进入 https://github.com/settings/personal-access-tokens/new 创建 fine-grained token。
3. Repository access 选择 Only select repositories，再选择 JiayiLong246.github.io。Repository permissions 的 Contents 设为 Read and write。
4. 打开插件“GitHub公开题库同步”，在本地密码输入框填入 token，勾选“每套完成后自动同步GitHub”，保存配置并允许访问GitHub API。
5. 点击“立即同步累计题库”，查看状态。之后每套完成后约10秒安排同步，累计题库与远端合并并去重，完成时若有更多新数据则再次安排同步。

凭据只填在本机扩展中，不需要发给助手。诊断导出只选择运行及学习字段，公开文件只选择题库字段。共享工具包中不包含你本机填写的凭据。

同步失败会显示错误并保留本地数据，下次完成一套或点击“立即同步累计题库”会再次尝试。token到期时在插件中更新。

## 访问者如何看到更新

刷题页每分钟检查GitHub公开题库，练习过程中显示更新按钮，其他页面可自动载入更新。GitHub Pages部署及CDN可能有延迟，联网且页面打开时才能检查更新。阅读版HTML是本次上传文件的快照，不随新采集自动重建。

每位访问者的练习进度、收藏和错题保存在自己的浏览器中。题库和网站公开，采集诊断日志由你主动导出提供排查。
