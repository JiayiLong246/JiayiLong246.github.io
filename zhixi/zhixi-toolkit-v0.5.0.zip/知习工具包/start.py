from pathlib import Path
from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from functools import partial
from threading import Timer
import webbrowser
root=Path(__file__).resolve().parent/'quiz-site/dist'
url='http://127.0.0.1:8765/'
with ThreadingHTTPServer(('127.0.0.1',8765),partial(SimpleHTTPRequestHandler,directory=str(root))) as server:
 print('Open '+url+' ; Ctrl+C to stop.',flush=True)
 Timer(.5,webbrowser.open,args=(url,)).start()
 try: server.serve_forever()
 except KeyboardInterrupt: pass
