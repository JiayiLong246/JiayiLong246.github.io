"""Import captured prompts into the local quiz site. Answers must be checked by a person."""
import hashlib,json,re,sys,html,os
from pathlib import Path
from itertools import chain
root=Path(__file__).resolve().parents[1]
target=root/'quiz-site/dist/questions.json'
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def samples(d):
 if 'questions' in d:
  yield from d['questions']
 if 'frames' in d:
  from bs4 import BeautifulSoup
  for f in d['frames']:
   for box in BeautifulSoup(f.get('structure',''),'html.parser').select('.question-list-box'):
    name=box.select_one('.name')
    if name:yield {'question':name.get_text(' ',strip=True),'options':[o.get_text(' ',strip=True) for o in box.select('.el-radio__label,.el-checkbox__label')]}
 for item in d.get('samples',[]):yield from samples(item)
def clean(s):return re.sub(r'\s+','',html.unescape(s))
def key(q):return (q['type'],clean(q['stem']),tuple(sorted(map(clean,q['options']))))
def main(files):
 rows=read(target)
 seen={key(q):q for q in rows}
 n=max((q['number'] for q in rows),default=0)
 added=updated=skipped=0
 for p in files:
  for raw in samples(read(p)):
   title=re.sub(r'^\s*\d+[.．、]\s*','',raw['question'])
   m=re.match(r'^【(单选题|多选题|判断题)】\s*(.+)$',title,re.S)
   kind=raw.get('type') or (m[1] if m else '')
   stem=(m[2] if m else title).strip()
   opts=[str(o).strip() for o in raw['options']]
   if kind=='判断题' and not opts:opts=['正确','错误']
   if not stem or kind not in ('单选题','多选题','判断题') or not 2<=len(opts)<=26 or any(not o for o in opts):
    skipped+=1;continue
   q={'type':kind,'stem':stem,'options':opts}
   k=key(q)
   correct=raw.get('answer')
   if correct is not None:
    if not isinstance(correct,list) or not correct or any(type(i) is not int or not 0<=i<len(opts) for i in correct) or len(set(correct))!=len(correct) or (kind!='多选题' and len(correct)!=1):
     raise ValueError(f'{p.name}: invalid answer for {stem[:40]}')
   if k in seen:
    row=seen[k]
    if correct is not None and not row['verified']:
     existing_options = [clean(option) for option in row['options']]
     if len(set(existing_options)) != len(existing_options):
      raise ValueError('Duplicate options prevent reliable answer mapping.')
     mapped = sorted(existing_options.index(clean(opts[i])) for i in correct)
     row.update(answer=mapped,verified=True,reference='；'.join(row['options'][i] for i in mapped),note=str(raw.get('note','')),status='reference')
     updated+=1
    else:skipped+=1
    continue
   n+=1
   q.update(number=n,id=hashlib.sha256(json.dumps(k,ensure_ascii=False).encode()).hexdigest()[:24],answer=sorted(correct or []),verified=correct is not None,reference='；'.join(opts[i] for i in sorted(correct)) if correct is not None else '待核对',note=str(raw.get('note','')) if correct is not None else '新采集题，尚未人工核对答案。',status='reference' if correct is not None else 'pending')
   rows.append(q);seen[k]=q;added+=1
 if added or updated:
  tmp=target.with_suffix('.tmp')
  tmp.write_text(json.dumps(rows,ensure_ascii=False,indent=2),encoding='utf-8')
  os.replace(tmp,target)
 print(f'Added: {added}; answers added: {updated}; skipped: {skipped}; total: {len(rows)}')
if __name__=='__main__':
 files=[Path(p) for p in sys.argv[1:]] or sorted((root/'samples').glob('*.json'))
 if not files:sys.exit('Put exported JSON files in samples/ or pass file paths.')
 main(files)
