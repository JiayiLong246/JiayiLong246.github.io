import os
from pathlib import Path
os.chdir(Path(__file__).resolve().parents[1])
import json,re,html,collections
from pathlib import Path
from xml.sax.saxutils import escape
from bs4 import BeautifulSoup
from reportlab.pdfgen import canvas
from reportlab.platypus import SimpleDocTemplate,Paragraph,Spacer,PageBreak,KeepTogether,Table,TableStyle
from reportlab.platypus.tableofcontents import TableOfContents
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib import colors
from reportlab.lib.enums import TA_LEFT
from reportlab.lib.pagesizes import A4
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
import fitz

BASE=Path.cwd();OUT=BASE/'outputs/党校考试复习资料_801题.pdf';QA=BASE/'work/pdf_qa';QA.mkdir(exist_ok=True)
pdfmetrics.registerFont(TTFont('Chinese','C:/Windows/Fonts/simsun.ttc',subfontIndex=0))
pdfmetrics.registerFont(TTFont('ChineseBold','C:/Windows/Fonts/simhei.ttf'))
pdfmetrics.registerFontFamily('Chinese',normal='Chinese',bold='ChineseBold')
qs=json.loads((BASE/'work/combined_questions_23.json').read_text(encoding='utf-8'))
assert qs
source_doc=BeautifulSoup((BASE/'outputs/党校考试复习资料_合并版.html').read_text(encoding='utf-8'),'html.parser')
sources=[(li.get('id'),li.a.get_text(' ',strip=True),li.a['href']) for li in source_doc.select('footer ol li') if li.a]
ink=colors.HexColor('#243c34');gray=colors.HexColor('#66736b');green=colors.HexColor('#245a40');amber=colors.HexColor('#8b5b29')
styles={
 'title':ParagraphStyle('title',fontName='ChineseBold',fontSize=24,leading=36,textColor=ink,spaceAfter=18),
 'subtitle':ParagraphStyle('subtitle',fontName='Chinese',fontSize=11,leading=18,textColor=gray,spaceAfter=15),
 'body':ParagraphStyle('body',fontName='Chinese',fontSize=10.5,leading=18,wordWrap='CJK',spaceAfter=10),
 'h1':ParagraphStyle('h1',fontName='ChineseBold',fontSize=18,leading=27,textColor=ink,spaceAfter=18,keepWithNext=True),
 'question':ParagraphStyle('question',fontName='ChineseBold',fontSize=10.8,leading=17.5,textColor=ink,spaceAfter=5,wordWrap='CJK'),
 'option':ParagraphStyle('option',fontName='Chinese',fontSize=10.3,leading=16.3,leftIndent=12,spaceAfter=2,wordWrap='CJK'),
 'answer':ParagraphStyle('answer',fontName='ChineseBold',fontSize=10.2,leading=16.5,textColor=green,spaceBefore=5,spaceAfter=4,wordWrap='CJK'),
 'note':ParagraphStyle('note',fontName='Chinese',fontSize=9,leading=14.5,textColor=amber,spaceAfter=5,wordWrap='CJK'),
 'source':ParagraphStyle('source',fontName='Chinese',fontSize=9,leading=15,spaceAfter=10,wordWrap='CJK'),
 'toc':ParagraphStyle('toc',fontName='Chinese',fontSize=12,leading=22,spaceAfter=9,textColor=ink),
}
class StudyDoc(SimpleDocTemplate):
 def afterFlowable(self,f):
  if isinstance(f,Paragraph) and f.style.name=='h1':
   title=f.getPlainText();key='section-'+str(self.page)
   self.canv.bookmarkPage(key);self.canv.addOutlineEntry(title,key,0,False)
   self.notify('TOCEntry',(0,title,self.page,key))
def footer(c,doc):
 c.saveState();w,h=A4;c.setStrokeColor(colors.HexColor('#d8dfd7'));c.setLineWidth(.4);c.line(43,36,w-43,36)
 c.setFont('Chinese',8);c.setFillColor(gray);c.drawString(43,23,'党校考试练习复习资料  |  801题  |  参考答案版')
 c.drawRightString(w-43,23,f'第 {doc.page} 页');c.restoreState()
story=[Spacer(1,24),Paragraph('党校考试练习复习资料',styles['title']),Paragraph('801题完整汇总  ·  题目  选项  参考答案  易错说明',styles['subtitle'])]
stats=collections.Counter(re.search('【(.*?)】',q['question'])[1] for q in qs)
story += [Paragraph('本资料包含截至2026年10月23日收录的801道题，按题型分类，保留汇总题号，方便与网站互相查找。全文文字可搜索、可复制，目录可点击跳转，适合手机离线阅读及打印。',styles['body']),
 Paragraph('题目构成：单选题446道，多选题90道，判断题265道。编号可能不连续，这是因为每类内部保留了原汇总编号。',styles['body']),
 Paragraph('<b>答案说明</b>：答案为根据题干和公开资料整理的参考答案，未经学校平台判分核验。37道版本、歧义或待核验题已在对应题目中说明，不宜直接背成唯一标准答案。选项字母对应本文首次收录的选项顺序；复习时应同时记忆答案文字。',styles['body']),
 Paragraph('阅读建议：先读题干与正确答案；遇到判断题，优先记住说明中纠正后的表述。涉及历史年份的题按指定年份理解，旧版条文和学校具体要求以题下注释为准。',styles['body']),
 Spacer(1,18),Paragraph('目录',styles['h1'])]
toc=TableOfContents();toc.levelStyles=[styles['toc']];story.append(toc)
# The introductory directory itself is not included in the navigable section list.
story[-2].style=ParagraphStyle('toc-title',parent=styles['h1'])
for kind in ['单选题','多选题','判断题']:
 story += [PageBreak(),Paragraph(kind+'  '+str(stats[kind])+'道',styles['h1'])]
 for q in qs:
  if kind not in q['question']:continue
  stem=html.unescape(re.sub(r'^\d+\.\s*','',q['question']))
  stem=re.sub(r'^【.*?】\s*','',stem)
  block=[Paragraph(str(q['number'])+'. '+escape(stem),styles['question'])]
  for i,o in enumerate(q['options']):block.append(Paragraph(chr(65+i)+'. '+escape(html.unescape(o)),styles['option']))
  block.append(Paragraph('参考答案：'+escape(html.unescape(q['reference_answer'])),styles['answer']))
  note=q.get('note','')
  if q.get('source'):note+='  核查来源：'+q['source']
  if note:block.append(Paragraph('说明：'+escape(html.unescape(note)),styles['note']))
  for v in q.get('option_variants',[]):
   block.append(Paragraph('其他批次选项版本（请按答案文字匹配）：',styles['note']))
   for i,o in enumerate(v):block.append(Paragraph(chr(65+i)+'. '+escape(html.unescape(o)),styles['option']))
  block.append(Spacer(1,11))
  story.append(KeepTogether(block))
story += [PageBreak(),Paragraph('重点核查来源',styles['h1']),Paragraph('以下资料用于核查相关规定及易混题，不代表逐题取得平台判分答案。正文中的S编号对应下列来源。点击标题可在联网时打开来源页面。',styles['body'])]
for key,title,url in sources:
 story.append(Paragraph(escape(key)+'  <link href="'+escape(url)+'" color="#245a40">'+escape(title)+'</link><br/><font size="8" color="#66736b">'+escape(url)+'</font>',styles['source']))
doc=StudyDoc(str(OUT),pagesize=A4,rightMargin=43,leftMargin=43,topMargin=43,bottomMargin=49,title='党校考试练习复习资料 801题',author='知习',subject='801道题及参考答案、易错说明',allowSplitting=1)
doc.multiBuild(story,onFirstPage=footer,onLaterPages=footer)
pdf=fitz.open(OUT)
text='\n'.join(p.get_text() for p in pdf)
heads=re.findall(r'(?m)^(\d{1,3})\.\s',text)
assert set(map(int,heads))==set(range(1,802)),(len(heads),set(range(1,802))-set(map(int,heads)))
assert text.count('参考答案：')==801,text.count('参考答案：')
assert len(pdf.get_toc())==4,pdf.get_toc()
assert all(len(p.get_text().strip())>50 for p in pdf)
pages=sorted(set([0,1,2,len(pdf)//3,len(pdf)//2,2*len(pdf)//3,len(pdf)-2,len(pdf)-1]+[r[2]-1 for r in pdf.get_toc()]))
for n in pages:pdf[n].get_pixmap(matrix=fitz.Matrix(1.25,1.25)).save(QA/f'page-{n+1}.png')
Path('work/pdf_qa/info.json').write_text(json.dumps({'pages':len(pdf),'size':OUT.stat().st_size,'sample_pages':[p+1 for p in pages],'toc':pdf.get_toc()},ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({'pages':len(pdf),'questions':801,'answers':text.count('参考答案：'),'bytes':OUT.stat().st_size,'sample_pages':[p+1 for p in pages]},ensure_ascii=False))
