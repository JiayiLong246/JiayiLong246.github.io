import os
from pathlib import Path
os.chdir(Path(__file__).resolve().parents[1])
from pathlib import Path
import re,html,json
from xml.sax.saxutils import escape
from reportlab.platypus import SimpleDocTemplate,Paragraph,Spacer,PageBreak,Table,TableStyle,KeepTogether
from reportlab.platypus.tableofcontents import TableOfContents
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
import fitz
base=Path('outputs/党校题库_分类记忆手册')
md=base.with_suffix('.md').read_text(encoding='utf-8-sig').replace('全民所有的国家权力','国家权力属于谁')
base.with_suffix('.md').write_text(md,encoding='utf-8')
lines=md.splitlines();blocks=[];i=0
while i<len(lines):
 t=lines[i].strip()
 if not t:i+=1;continue
 if t.startswith('|'):
  rows=[]
  while i<len(lines) and lines[i].strip().startswith('|'):
   row=[x.strip() for x in lines[i].strip().strip('|').split('|')]
   if not all(re.fullmatch(r'[:\-\s]+',x) for x in row):rows.append(row)
   i+=1
  blocks.append(('table',rows));continue
 if t.startswith('# '):blocks.append(('title',t[2:]))
 elif t.startswith('## '):blocks.append(('h',t[3:]))
 else:blocks.append(('p',t))
 i+=1
heads=[v for k,v in blocks if k=='h']
# All references must exist in the source question bank.
nums=[int(n) for n in re.findall(r'#(\d+)',md)]
qs=json.loads(Path('work/combined_questions_23.json').read_text(encoding='utf-8'));assert all(n in {q['number'] for q in qs} for n in nums)
rows_count=sum(len(v)-1 for k,v in blocks if k=='table')
css='''body{margin:0;background:#f4f3ed;color:#223c34;font:16px/1.85 system-ui,"Microsoft YaHei",sans-serif}main{max-width:1080px;margin:auto;padding:36px 24px 70px}h1{font-size:34px;line-height:1.4}h2{margin-top:48px;padding-top:18px;border-top:2px solid #bad1c4;scroll-margin-top:70px}table{width:100%;border-collapse:collapse;background:#fff;margin:20px 0}th,td{padding:13px 15px;border:1px solid #d9e1db;vertical-align:top;text-align:left}th{background:#dceadf}td:first-child{width:23%;font-weight:650}td:nth-child(2){width:43%}nav{padding:18px;background:#e4ebe1;border-radius:14px}nav a{display:inline-block;margin:5px 18px 5px 0;color:#235543}a{overflow-wrap:anywhere}button{background:#244b3c;color:#fff;border:0;border-radius:8px;padding:10px 18px;cursor:pointer}header{position:sticky;top:0;background:#f4f3edf0;padding:8px 0;display:flex;gap:20px;align-items:center}body.recall td:nth-child(2){color:transparent;user-select:none}body.recall td:nth-child(2):hover,body.recall td:nth-child(2):focus{color:#223c34;user-select:text}p{margin:16px 0}@media(max-width:620px){main{padding:20px 12px}h1{font-size:27px}th,td{padding:8px 7px;font-size:14px}}@media print{body{background:white;font-size:10pt}main{padding:0}header{display:none}h2{break-before:page}table{font-size:9pt}tr{break-inside:avoid}body.recall td:nth-child(2){color:#223c34}}'''
out=['<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>党校题库分类记忆手册</title><style>'+css+'</style><main><header><button onclick="document.body.classList.toggle(\'recall\')">遮住 / 显示知识点</button><span>浏览器查找可搜索全文；触碰隐藏单元格可查看</span></header>']
def linked(s):
 s=html.escape(s)
 return re.sub(r'https://[^\s<]+',lambda m:'<a href="'+m[0]+'">'+m[0]+'</a>',s)
idx=0
for k,v in blocks:
 if k=='title':out+=['<h1>'+linked(v)+'</h1><p>14类主题 · '+str(rows_count)+'条对照条目 · 保留原题号</p><nav>'+''.join(f'<a href="#s{n}">{html.escape(t)}</a>' for n,t in enumerate(heads))+'</nav>']
 elif k=='h':out.append(f'<h2 id="s{idx}">'+linked(v)+'</h2>');idx+=1
 elif k=='table':out.append('<table>'+''.join('<tr>'+''.join(('<th>' if n==0 else '<td tabindex="0">')+linked(c)+('</th>' if n==0 else '</td>') for c in row)+'</tr>' for n,row in enumerate(v))+'</table>')
 else:out.append('<p>'+linked(v)+'</p>')
out.append('</main></html>');base.with_suffix('.html').write_text('\n'.join(out),encoding='utf-8')
pdfmetrics.registerFont(TTFont('CN','C:/Windows/Fonts/simsun.ttc',subfontIndex=0));pdfmetrics.registerFont(TTFont('CNBold','C:/Windows/Fonts/simhei.ttf'));pdfmetrics.registerFontFamily('CN',normal='CN',bold='CNBold')
styles={
 'title':ParagraphStyle('title',fontName='CNBold',fontSize=25,leading=38,textColor=colors.HexColor('#244b3c'),spaceAfter=18),
 'h':ParagraphStyle('h',fontName='CNBold',fontSize=17,leading=27,spaceAfter=15,textColor=colors.HexColor('#244b3c'),keepWithNext=True),
 'body':ParagraphStyle('body',fontName='CN',fontSize=10.5,leading=18,spaceAfter=11,wordWrap='CJK'),
 'cell':ParagraphStyle('cell',fontName='CN',fontSize=9.5,leading=15,wordWrap='CJK'),
 'cellbold':ParagraphStyle('cellbold',fontName='CNBold',fontSize=9.5,leading=15,wordWrap='CJK'),
 'toc':ParagraphStyle('toc',fontName='CN',fontSize=10.5,leading=18,spaceAfter=3),
}
def P(t,kind='body'):
 txt=escape(t)
 txt=re.sub(r'https://[^\s<]+',lambda m:'<link href="'+m[0]+'" color="#245a40">'+m[0]+'</link>',txt)
 return Paragraph(txt,styles[kind])
class Doc(SimpleDocTemplate):
 def afterFlowable(self,f):
  if isinstance(f,Paragraph) and f.style.name=='h':
   title=f.getPlainText();key='h'+str(self.page);self.canv.bookmarkPage(key);self.canv.addOutlineEntry(title,key,0,False);self.notify('TOCEntry',(0,title,self.page,key))
def footer(c,doc):
 c.saveState();c.setFont('CN',8);c.setFillColor(colors.HexColor('#66756c'));c.drawString(39,25,'党校题库分类记忆手册  |  主题归纳与易混辨析');c.drawRightString(A4[0]-39,25,str(doc.page));c.restoreState()
story=[];made_toc=False
for k,v in blocks:
 if k=='title':story+=[Spacer(1,25),P(v,'title'),P(f'14类主题 · {rows_count}条对照条目 · 原题号索引')]
 elif k=='h':
  if not made_toc:
   story+=[Spacer(1,10),P('目录','title')];toc=TableOfContents();toc.levelStyles=[styles['toc']];story+=[toc];made_toc=True
  story+=[PageBreak(),P(v,'h')]
 elif k=='table':
  data=[[P(c,'cellbold' if n==0 or j==0 else 'cell') for j,c in enumerate(row)] for n,row in enumerate(v)]
  table=Table(data,colWidths=[117,220,A4[0]-78-337],repeatRows=1,hAlign='LEFT')
  table.setStyle(TableStyle([('VALIGN',(0,0),(-1,-1),'TOP'),('BACKGROUND',(0,0),(-1,0),colors.HexColor('#dceadf')),('ROWBACKGROUNDS',(0,1),(-1,-1),[colors.white,colors.HexColor('#f5f7f2')]),('GRID',(0,0),(-1,-1),.35,colors.HexColor('#cbd8cd')),('LEFTPADDING',(0,0),(-1,-1),8),('RIGHTPADDING',(0,0),(-1,-1),8),('TOPPADDING',(0,0),(-1,-1),9),('BOTTOMPADDING',(0,0),(-1,-1),9)]))
  story+=[table,Spacer(1,12)]
 else:story.append(P(v))
doc=Doc(str(base.with_suffix('.pdf')),pagesize=A4,rightMargin=39,leftMargin=39,topMargin=42,bottomMargin=45,title='党校题库分类记忆手册',author='个人复习资料')
doc.multiBuild(story,onFirstPage=footer,onLaterPages=footer)
pdf=fitz.open(base.with_suffix('.pdf'));qa=Path('work/knowledge_qa');qa.mkdir(exist_ok=True)
text='\n'.join(p.get_text() for p in pdf)
assert all(t in text for t in ['共产党宣言','八义八权','入党时间与党龄','50=37+13'])
for i in sorted({0,1,2,3,5,8,len(pdf)//2,len(pdf)-2,len(pdf)-1}):
 pdf[i].get_pixmap(matrix=fitz.Matrix(1.3,1.3)).save(qa/f'page-{i+1}.png')
print(json.dumps({'cards':rows_count,'pages':len(pdf),'unique_question_references':len(set(nums)),'files':[str(base.with_suffix(x)) for x in ['.pdf','.html','.md']]},ensure_ascii=False))
