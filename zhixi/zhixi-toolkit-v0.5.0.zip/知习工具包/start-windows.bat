@echo off
cd /d "%~dp0"
where py >nul 2>nul
if errorlevel 1 goto python
py -3 start.py
goto done
:python
python start.py
:done
pause
